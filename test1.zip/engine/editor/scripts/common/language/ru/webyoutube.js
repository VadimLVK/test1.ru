function loadTxt() {
  document.getElementById("tab0").innerHTML = "YOUTUBE";
  document.getElementById("tab1").innerHTML = "\u0421\u0422\u0418\u041b\u0418";
  document.getElementById("tab2").innerHTML = "\u0420\u0410\u0417\u041c\u0415\u0420\u042b";
  document.getElementById("lnkLoadMore").innerHTML = "\u0417\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435";
  document.getElementById("lblUrl").innerHTML = "\u0421\u0441\u044b\u043b\u043a\u0430:";
  document.getElementById("btnCancel").value = "\u041e\u0442\u043c\u0435\u043d\u0438\u0442\u044c";
  document.getElementById("btnInsert").value = "\u0412\u0441\u0442\u0430\u0432\u0438\u0442\u044c";
  document.getElementById("btnSearch").value = " \u041d\u0430\u0439\u0442\u0438 ";
}
function writeTitle() {
  document.write("<title>" + "Youtube \u0412\u0438\u0434\u0435\u043e" + "</title>")
}
;