function loadTxt() {
  document.getElementById("tab0").innerHTML = "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442\u043d\u044b\u0435";
  document.getElementById("tab1").innerHTML = "GOOGLE \u043a\u0438\u0440\u0438\u043b\u043b\u0438\u0446\u0430";
  document.getElementById("tab2").innerHTML = "GOOGLE \u043b\u0430\u0442\u0438\u043d\u0438\u0446\u0430"
}
function writeTitle() {
  document.write("<title>" + "\u0428\u0440\u0438\u0444\u0442\u044b" + "</title>")
}
;