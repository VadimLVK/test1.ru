function loadTxt() {
}
function writeTitle() {
  document.write("<title>" + "\u0421\u043f\u0435\u0446\u0438\u0430\u043b\u044c\u043d\u044b\u0435 \u0441\u0438\u043c\u0432\u043e\u043b\u044b" + "</title>")
}
;