tinyMCE.addI18n('ru.advhr_dlg',{
width:"\u0428\u0438\u0440\u0438\u043D\u0430",
size:"\u0412\u044B\u0441\u043E\u0442\u0430",
noshade:"\u041D\u0435\u0442 \u0442\u0435\u043D\u0438",
normal:"Normal",
widthunits:"Units"
});